const express = require('express');
const app = express();

app.use(express.json());

const PORT = 3000;

// In-memory data
let bookings = [];

// Add Booking
app.post('/bookings', (req, res) => {
    const { id, movie, customer, tickets } = req.body;

    const newBooking = { id, movie, customer, tickets };
    bookings.push(newBooking);

    res.json({ message: "Booking added successfully", booking: newBooking });
});

// View All Bookings
app.get('/bookings', (req, res) => {
    res.json(bookings);
});

// View Booking by ID
app.get('/bookings/:id', (req, res) => {
    const booking = bookings.find(b => b.id == req.params.id);

    if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
    }

    res.json(booking);
});

// Update Booking
app.put('/bookings/:id', (req, res) => {
    console.log("BODY:", req.body); 

    const booking = bookings.find(b => b.id == req.params.id);

    if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
    }

    const { movie, customer, tickets } = req.body;

    if (movie) booking.movie = movie;
    if (customer) booking.customer = customer;
    if (tickets) booking.tickets = tickets;

    res.json({ message: "Booking updated", booking });
});

// Delete Booking
app.delete('/bookings/:id', (req, res) => {
    bookings = bookings.filter(b => b.id != req.params.id);

    res.json({ message: "Booking deleted" });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});