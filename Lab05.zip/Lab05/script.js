let form = document.forms[0];
let title=document.getElementsByTagName("h1")[0];
let image = document.getElementById("travelImg");
let table = document.getElementById("travelerT");

//Task 1: DOM Traversal
let formContainer = form.parentNode;       //parentNode usage
let inputs = form.children;                //children usage

for(let i=0;i<inputs.length; i++){
    //change background of all INPUT fields
    if(inputs[i].tagName === "INPUT"){
        inputs[i].style.backgroundColor = "#eef";
    }
    console.log("Child tag:", inputs[i].tagName);
}

//Task 2: Dynamic traveler counter
let countPara = document.createElement("p");
countPara.id = "travelerCount";
countPara.innerText = "Total Registered Travelers: 0";
document.body.appendChild(countPara);

function updateCount(){
    //rows length includes header row, so -1
    let count =table.rows.length -1;
    countPara.innerText= "Total Registered Travelers: " +count;
}

// Add Traveler on Form Submit
form.addEventListener("submit", function (e) {
  e.preventDefault(); // Prevent page reload

  let name = nameInput.value.trim();
  let age = parseInt(ageInput.value, 10);
  let email = emailInput.value.trim();

  // Create new table row
  let row = table.insertRow();

  let nameCell = row.insertCell(0);
  let ageCell = row.insertCell(1);
  let emailCell = row.insertCell(2);
  let actionCell = row.insertCell(3);

  nameCell.innerText = name;
  ageCell.innerText = age;
  emailCell.innerText = email;

  // Add delete button
  let deleteBtn = document.createElement("button");
  deleteBtn.innerText = "Delete";
  actionCell.appendChild(deleteBtn);

// Task 3: Conditional styling based on age
  if (age < 18) {
    row.style.backgroundColor = "#fff3cd";   // Under 18 - yellow
  } else if (age >= 60) {
    row.style.backgroundColor = "#d1ecf1";   // Seniors - light blue
  }

  // Reset form and update counter
  form.reset();
  submitBtn.disabled = true;
  updateCount();
});


//Task 4: Real-time form validation
let submitBtn = document.querySelector("input[type='submit']");
let nameInput = document.getElementById("name");
let ageInput = document.getElementById("age");
let emailInput = document.getElementById("email");

submitBtn.disabled= true;

function validateForm(){
    let valid = true;

    if(nameInput.value.trim() ===""){
        nameInput.style.border= "2px solid red";
        valid = false;
    } else {
        nameInput.style.border = "";
    }

    // simple validation for age
    let ageVal = parseInt(ageInput.value, 10);
    if (isNaN(ageVal) || ageVal <= 0) {
      ageInput.style.border = "2px solid red";
      valid = false;
    } else {
       ageInput.style.border = "";
    }

    if (!emailInput.value.includes("@")) {
       emailInput.style.border = "2px solid red";
       valid = false;
    }else {
       emailInput.style.border = "";
    }

    submitBtn.disabled = !valid;
}

nameInput.onkeyup = validateForm;
ageInput.onkeyup = validateForm;
emailInput.onkeyup = validateForm;


//Task 5:Dynamic filtering by age group
document.getElementById("ageFilter").onchange = function () {
   let filter = this.value;
   let rows = table.rows;

   for (let i = 1; i < rows.length; i++) {
      let age = parseInt(rows[i].cells[1].innerText, 10);
      rows[i].style.display = "table-row";

      if (filter === "under18" && age >= 18) rows[i].style.display = "none";
      if (filter === "adult" && (age < 18 || age >= 60)) rows[i].style.display = "none";
      if (filter === "senior" && age < 60) rows[i].style.display = "none";
   }
};

// Task 6: Event delegation for delete buttons
table.addEventListener("click", function (e) {
    if (e.target.tagName === "BUTTON") {
      let row = e.target.parentNode.parentNode;
      row. remove();
      updateCount();
    }
});