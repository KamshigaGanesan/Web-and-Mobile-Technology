/*
Student ID: IT24101365
Name: Kamshiga Ganesan
*/

window.onload = function () {
    console.log("Page URL:", document.URL);
    console.log("Last Modified:", document.lastModified);
    document.title = "Library Seat Booking - DOM Test";

    let title = document.getElementsByTagName("h1")[0];
    title.style.color = "#147d1b";
    title.style.fontSize = "34px";
 


setTimeout(function () {
    document.body.style.backgroundColor = "#D3D3D3";
}, 2000);



let image = document.getElementById("libraryImage");

image.onmouseover = function () {
    image.style.border = "5px solid #0000ff";
};

image.onmouseout = function () {
    image.style.border = "none";
};
let seatTable = document.getElementById("seatTable");

seatTable.addEventListener("click", function () {
    alert("Seat Categories table clicked");
});



let nameField = document.getElementById("studentName");

nameField.onkeyup = function () {
    nameField.style.backgroundColor = "#FFFF00";
};





let secondImage = new Image();
secondImage.src = "library2.jpeg";

let toggled = false;


image.ondblclick = function () {
    if (toggled === false) {
        image.src = secondImage.src;
        toggled = true;
    } else {
        image.src = "library1.jpg";
        toggled = false;
    }
};



let form = document.getElementById("bookingForm");
let bookedTable = document.getElementById("bookingTable");

form.onsubmit = function (event) {
    event.preventDefault();

    let studentName = document.getElementById("studentName").value;
    let studentEmail = document.getElementById("studentEmail").value;

    let row = bookedTable.insertRow();

    row.insertCell(0).innerText = studentName;
    row.insertCell(1).innerText = studentEmail;

    let deleteCell = row.insertCell(2);
    let btn = document.createElement("button");
    btn.innerText = "Delete";

    btn.onclick = function () {
        bookedTable.deleteRow(row.rowIndex);
    };

    deleteCell.appendChild(btn);

    form.reset();
};

window.onresize = function () {
    console.log("Window resized");
};
};