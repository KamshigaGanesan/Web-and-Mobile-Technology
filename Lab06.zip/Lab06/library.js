const fs = require('fs');

const addBook = require('./addBook');
const searchBook = require('./searchBook');
const borrowBook = require('./borrowBook');
const returnBook = require('./returnBook');
const deleteBook = require('./deleteBook');
const displayBooks = require('./displayBooks');

let library = JSON.parse(fs.readFileSync('./bookList.json','utf8'));

console.log("\nInitial Library");
displayBooks(library);

addBook(library,"1984","George Orwell",1949);

searchBook(library,"Harry Potter");

borrowBook(library,1);

returnBook(library,1);

deleteBook(library,2);

console.log("\nUpdated Library");
displayBooks(library);

fs.writeFileSync('./bookList.json', JSON.stringify(library,null,2));