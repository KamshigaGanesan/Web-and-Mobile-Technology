function searchBook(library, title){

let found = library.find(
b => b.title.toLowerCase() === title.toLowerCase()
);

if(found){
console.log(found.title, "-", found.isAvailable ? "Available" : "Borrowed");
}
else{
console.log("Book not found");
}

}

module.exports = searchBook;