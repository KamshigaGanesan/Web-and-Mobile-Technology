function borrowBook(library, id){

let book = library.find(b => b.id === id);

if(!book){
console.log("Book not found");
return;
}

if(!book.isAvailable){
console.log("Book already borrowed");
return;
}

book.isAvailable = false;

console.log("Borrowed:", book.title);

}

module.exports = borrowBook;