function addBook(library, title, author, year){

let newBook = {
id: library.length + 1,
title: title,
author: author,
year: year,
isAvailable: true
};

library.push(newBook);

console.log("Book added:", title);

}

module.exports = addBook;