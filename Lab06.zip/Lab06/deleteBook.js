function deleteBook(library, id){

let index = library.findIndex(b => b.id === id);

if(index === -1){
console.log("Book not found");
return;
}

library.splice(index,1);

console.log("Book deleted");

}

module.exports = deleteBook;