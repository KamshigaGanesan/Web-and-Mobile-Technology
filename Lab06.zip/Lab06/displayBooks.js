function displayBooks(library){

console.log("\nLibrary Books\n");

library.forEach(book => {

let status = book.isAvailable ? "Available" : "Borrowed";

console.log(`${book.id}. ${book.title} - ${status}`);

});

}

module.exports = displayBooks;
