function returnBook(library, id){

let book = library.find(b => b.id === id);

if(!book){
console.log("Book not found");
return;
}

book.isAvailable = true;

console.log("Returned:", book.title);

}

module.exports = returnBook;