// Minimum age
const minAge = 18;

// Array to store students
let students = [];

function submitForm() {
    let name = document.getElementById("name").value;
    let age = Number(document.getElementById("age").value);
    let email = document.getElementById("email").value;
    let phone = document.getElementById("phone").value;

    switch (true) {
        case name === "" || email === "":
            alert("Validation failed: Empty fields");
            return false;

        case age < minAge:
            alert("Validation failed: Age below 18");
            return false;

        case phone.length !== 10:
            alert("Validation failed: Phone number must be at least 10 digits");
            return false;

        default:
            alert("Validation successful");
    }

    //Create student object
    let student = {
        name: name,
        age: age,
        email: email,
        phoneNumber: phone
    };

    //Store student
    students.push(student);

    //Display students in console and alert
    let message="Student List:\n";
    console.log("Student List:");

    for (let i = 0; i < students.length; i++) {
        let details=
            (i+1)+ ". Name:"+ students[i].name+
            ", Age:"+ students[i].age+
            ", Email:"+ students[i].email+
            ", Phone:"+ students[i].phoneNumber;
        
            
        console.log(details);
        message +=details +"\n";
    }
    alert(message);

    // Clear form
    document.getElementById("name").value = "";
    document.getElementById("age").value = "";
    document.getElementById("email").value = "";
    document.getElementById("phone").value = "";

    document.getElementById("name").focus();

    return false; // prevent refresh
}
